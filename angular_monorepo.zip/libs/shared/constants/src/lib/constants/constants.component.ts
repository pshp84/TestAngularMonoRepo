import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'lib-constants',
  imports: [CommonModule],
  templateUrl: './constants.component.html',
  styleUrl: './constants.component.css',
})
export class ConstantsComponent {}
