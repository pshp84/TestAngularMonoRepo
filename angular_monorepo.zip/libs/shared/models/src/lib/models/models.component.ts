import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'lib-models',
  imports: [CommonModule],
  templateUrl: './models.component.html',
  styleUrl: './models.component.css',
})
export class ModelsComponent {}
