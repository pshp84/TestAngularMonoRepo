import { Route } from '@angular/router';

export const appRoutes: Route[] = [
  {
    path: 'dashboard',
    loadChildren: () =>
      import('@angular-monorepo/dashboard').then((m) => m.dashboardRoutes),
  },
  {
    path: 'auth',
    loadChildren: () =>
      import('@angular-monorepo/auth').then((m) => m.authRoutes),
  },
];
